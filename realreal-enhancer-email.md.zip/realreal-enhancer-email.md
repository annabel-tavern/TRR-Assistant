**Subject:** chrome extension that makes shopping the realreal way faster

---

hey!

i made a little chrome extension that makes shopping the realreal so much better and thought you might want it.

basically it does three things:

**filter presets** — this is the main thing. you know how every time you search a new designer you have to re-apply all your filters? size, condition, sort by price, etc? this lets you save those filters once and then apply them to any designer page with one click. so you can go from ganni to rag and bone to isabel marant and just click your preset each time instead of manually setting everything up again.

**compact view** — squeezes more items per row so you can scan faster without endless scrolling.

**dim sold items** — fades out the sold stuff so your eyes skip right to what's actually available.

it honestly makes the whole experience feel way faster. i used to get sucked in for an hour and by the time i was ready to checkout things had already sold. now i can get through my brands in like 15 minutes.

to install it (takes 2 min):

1. download and unzip the file [ATTACH LINK HERE]
2. open chrome and go to chrome://extensions
3. turn on "developer mode" (little toggle in the top right corner)
4. click "load unpacked" and select the unzipped folder
5. go to therealreal.com — you'll see a toolbar at the bottom of the page

from there just apply your filters like normal, hit "+ save current filters" in the toolbar, name it, and you're set. next time you're browsing a different designer just click your preset and it applies those same filters right there.

hover over any preset to edit or delete it. and you can shift+click a preset if you want to go back to the exact original page instead of applying filters to where you are.

lmk if you have any issues!
